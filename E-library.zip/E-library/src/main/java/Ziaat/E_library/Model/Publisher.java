package Ziaat.E_library.Model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="Publisher")
public class Publisher {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstname;
    private String lastname;
    private Boolean isActive;

    // Getters and Setters
}

