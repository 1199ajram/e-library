package Ziaat.E_library.Model;

import Ziaat.E_library.Enumerated.CopyStatus;
import Ziaat.E_library.Enumerated.CopyType;
import jakarta.persistence.*;

import java.awt.print.Book;
import java.time.LocalDateTime;

@Entity
public class BookCopy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long copyId;

    @ManyToOne
    @JoinColumn(name = "book_id")
    private Book book;

    @Enumerated(EnumType.STRING)
    private CopyType copyType;

    private String identifier;
    private String location;

    @Enumerated(EnumType.STRING)
    private CopyStatus status;

    private LocalDateTime addedAt;
}

