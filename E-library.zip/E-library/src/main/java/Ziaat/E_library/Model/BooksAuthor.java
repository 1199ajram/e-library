package Ziaat.E_library.Model;
import jakarta.persistence.*;
import java.awt.print.Book;

@Entity
@Table(name = "books_author")
public class BooksAuthor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", nullable = false)
    private Author author;

    @Column(name = "is_active")
    private Boolean isActive;


    // Getters and Setters
}
