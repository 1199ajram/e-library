package Ziaat.E_library.Dto;

import lombok.Data;

@Data
public class PublisherResponse {
    private Long id;
    private String firstname;
    private String lastname;
    private Boolean isActive;
}

