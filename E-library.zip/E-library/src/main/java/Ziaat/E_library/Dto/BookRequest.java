package Ziaat.E_library.Dto;

import java.time.LocalDate;

public class BookRequest {
    private String title;
    private String isbn;
    private Long publisherId;
    private Long categoryId;
    private LocalDate publishedDate;
    private String description;
    private String language;
    private int pageCount;
    private String coverImageUrl;
}
