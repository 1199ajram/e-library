package Ziaat.E_library.Dto;

import lombok.Data;

@Data
public class PublisherRequest {
    private String firstname;
    private String lastname;
    private Boolean isActive;
}

