package Ziaat.E_library.Dto;

import lombok.Data;

@Data
public class CategoryRequest {
    private String name;
    private Boolean isActive;
}

