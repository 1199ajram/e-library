package Ziaat.E_library.Dto;

import lombok.Data;

@Data
public class AuthorRequest {
    private String firstname;
    private String lastname;
    private Boolean isActive;
}

