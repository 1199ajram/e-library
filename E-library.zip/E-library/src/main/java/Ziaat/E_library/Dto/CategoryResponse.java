package Ziaat.E_library.Dto;

import lombok.Data;

@Data
public class CategoryResponse {
    private Long id;
    private String name;
    private Boolean isActive;
}

