package Ziaat.E_library.Services;

import Ziaat.E_library.Dto.PublisherRequest;
import Ziaat.E_library.Dto.PublisherResponse;
import Ziaat.E_library.Model.Publisher;
import Ziaat.E_library.Repository.PublisherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PublisherService {

    @Autowired
    private PublisherRepository publisherRepository;

    public PublisherResponse createPublisher(PublisherRequest request) {
        Publisher publisher = new Publisher();
        publisher.setFirstname(request.getFirstname());
        publisher.setLastname(request.getLastname());
        publisher.setIsActive(request.getIsActive());
        return mapToResponse(publisherRepository.save(publisher));
    }

    public PublisherResponse updatePublisher(Long id, PublisherRequest request) {
        Publisher publisher = publisherRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Publisher not found"));
        publisher.setFirstname(request.getFirstname());
        publisher.setLastname(request.getLastname());
        publisher.setIsActive(request.getIsActive());
        return mapToResponse(publisherRepository.save(publisher));
    }

    public void deletePublisher(Long id) {
        publisherRepository.deleteById(id);
    }

    public PublisherResponse getPublisher(Long id) {
        Publisher publisher = publisherRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Publisher not found"));
        return mapToResponse(publisher);
    }

    private PublisherResponse mapToResponse(Publisher publisher) {
        PublisherResponse response = new PublisherResponse();
        response.setId(publisher.getId());
        response.setFirstname(publisher.getFirstname());
        response.setLastname(publisher.getLastname());
        response.setIsActive(publisher.getIsActive());
        return response;
    }
}

