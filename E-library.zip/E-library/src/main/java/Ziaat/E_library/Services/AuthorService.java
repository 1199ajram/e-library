package Ziaat.E_library.Services;

import Ziaat.E_library.Dto.AuthorRequest;
import Ziaat.E_library.Dto.AuthorResponse;
import Ziaat.E_library.Model.Author;
import Ziaat.E_library.Repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthorService {

    @Autowired
    private AuthorRepository authorRepository;

    public AuthorResponse createAuthor(AuthorRequest request) {
        Author author = new Author();
        author.setFirstname(request.getFirstname());
        author.setLastname(request.getLastname());
        author.setIsActive(request.getIsActive());
        return mapToResponse(authorRepository.save(author));
    }

    public AuthorResponse updateAuthor(Long id, AuthorRequest request) {
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Author not found"));
        author.setFirstname(request.getFirstname());
        author.setLastname(request.getLastname());
        author.setIsActive(request.getIsActive());
        return mapToResponse(authorRepository.save(author));
    }

    public void deleteAuthor(Long id) {
        authorRepository.deleteById(id);
    }

    public AuthorResponse getAuthor(Long id) {
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Author not found"));
        return mapToResponse(author);
    }

    private AuthorResponse mapToResponse(Author author) {
        AuthorResponse response = new AuthorResponse();
        response.setId(author.getId());
        response.setFirstname(author.getFirstname());
        response.setLastname(author.getLastname());
        response.setIsActive(author.getIsActive());
        return response;
    }
}

