package Ziaat.E_library.Controllers;

import Ziaat.E_library.Dto.PublisherRequest;
import Ziaat.E_library.Dto.PublisherResponse;
import Ziaat.E_library.Services.PublisherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/publishers")
public class PublisherController {

    @Autowired
    private PublisherService publisherService;

    @PostMapping("/createPublisher")
    public ResponseEntity<PublisherResponse> create(@RequestBody PublisherRequest request) {
        return ResponseEntity.ok(publisherService.createPublisher(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PublisherResponse> update(@PathVariable Long id, @RequestBody PublisherRequest request) {
        return ResponseEntity.ok(publisherService.updatePublisher(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        publisherService.deletePublisher(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PublisherResponse> get(@PathVariable Long id) {
        return ResponseEntity.ok(publisherService.getPublisher(id));
    }
}

