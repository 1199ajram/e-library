package Ziaat.E_library.Enumerated;

public enum CopyStatus {
    AVAILABLE, CHECKED_OUT, RESERVED, LOST, MAINTENANCE
}

