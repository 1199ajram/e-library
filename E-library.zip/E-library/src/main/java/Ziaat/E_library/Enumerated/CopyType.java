package Ziaat.E_library.Enumerated;

public enum CopyType {
    PHYSICAL, DIGITAL
}

