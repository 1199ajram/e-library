package Ziaat.E_library.Repository;

import Ziaat.E_library.Model.BooksAuthor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BooksAuthorRepository extends JpaRepository<BooksAuthor, Long> {
    List<BooksAuthor> findByIsActiveTrue();
    List<BooksAuthor> findByBook_Id(Long bookId);
    List<BooksAuthor> findByAuthor_Id(Long authorId);
}

