package Ziaat.E_library.Repository;

import Ziaat.E_library.Enumerated.CopyStatus;
import Ziaat.E_library.Model.BookCopy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookCopyRepository extends JpaRepository<BookCopy, Long> {
    List<BookCopy> findByStatus(CopyStatus status);
    List<BookCopy> findByBookId(Long bookId);
}

