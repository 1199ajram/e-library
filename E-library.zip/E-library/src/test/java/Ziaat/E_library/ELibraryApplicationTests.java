package Ziaat.E_library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ELibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
